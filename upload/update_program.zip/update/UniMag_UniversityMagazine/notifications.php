<?php
session_start();
require_once("include/connect.php");

$userid = $_SESSION['userid'];

$res = mysqli_query($connection, "
SELECT n.*, c.title
FROM tblnotification_log n
JOIN tblcontribution c ON n.contributionid = c.contributionid
WHERE n.sent_to = '$userid'
ORDER BY n.notificationid DESC
");
?>

<h3>Notifications</h3>

<?php while($row = mysqli_fetch_array($res)){ ?>

<div>
    🔔 Contribution: <b><?php echo $row['title']; ?></b><br>
    Date: <?php echo $row['sent_date']; ?>
</div>

<?php } ?>

<?php
// mark as read
mysqli_query($connection, "
UPDATE tblnotification_log 
SET status='read' 
WHERE sent_to = '$userid'
");
?>