<?php
session_start();
require_once("include/connect.php");

if (!isset($_SESSION['userid'])) {
    echo "<script>
        alert('Please login first');
        window.location='login.php';
    </script>";
    exit();
}

if (!isset($_SESSION['roleid']) || $_SESSION['roleid'] != 1) {
    echo "<script>
        alert('Access denied! Only Admin allowed.');
        window.location='login.php';
    </script>";
    exit();
}

if (isset($_GET['id'])) {

    $categoryid = $_GET['id'];
    $today = date("Y-m-d");

    $q = mysqli_query($connection, "SELECT * 
                                    FROM tblcategory 
                                    WHERE categoryid='$categoryid'
                                    ");
    $data = mysqli_fetch_array($q);
    $categoryname = $data["categoryname"];
    $categorystartdate = $data["categorystartdate"];
    $categoryclosuredate = $data["categoryclosuredate"];

    

    // $q = mysqli_query($connection, "
    // SELECT categoryclosuredate 
    // FROM tblcategory 
    // WHERE categoryid='$categoryid'
    // ");

    // $data = mysqli_fetch_array($q);

    if (!$data) {
        die("Invalid category");
    }
}

// Proceed with update code here

if ($end < $start) {
    echo "<script>alert('End date cannot be earlier than Start date');
            window.location='category_update.php';
        </script>";
    return;
}

// check within academic year
$checkYear = mysqli_query($connection, "
    SELECT submission_closure_date, final_closure_date 
    FROM tblacademicyear 
    WHERE academicyearid = '$academicyearid'
");

$year = mysqli_fetch_assoc($checkYear);

if ($start < $year['submission_closure_date'] || $end > $year['final_closure_date']) {
    echo "<script>alert('Invalid category dates');</script>";
    return;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <div class="container-fluid">

        <div class="row">

            <!-- SIDEBAR -->

            <div class="col-lg-2 col-md-3 sidebar p-3">

                <h4 class="text-center mb-4">Admin Panel</h4>

                <a href="student_contribution.php"><i class="fa fa-home"></i> Dashboard</a>

                <a href="academic_year_register.php"><i class="fa fa-user-tie"></i> Manage Academic Year</a>

                <a href="category_register.php"><i class="fa fa-user-tie"></i> Manage Category</a>

                <a href="register.php"><i class="fa fa-users"></i> Manage Users</a>

                <!-- <a href="student_contribution.php"><i class="fa fa-folder"></i> Student Contribution</a> -->

                <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>

            </div>


            <!-- MAIN CONTENT -->

            <div class="col-lg-10 col-md-9 p-4">

                <h3 class="mb-4">Category Management</h3>

                <div class="row">

                    <!-- ADD ACADEMIC YEAR FORM -->

                    <div class="col-lg-12 col-md-12 mb-4">

                        <div class="card p-3">

                            <h5 class="mb-3">Update Category</h5>

                            <form method="POST" action="#">
                                <input type="hidden" name="categoryid" value="<?php echo $categoryid; ?>">

                                <div class="mb-3">

                                    <label>Category Name</label>

                                    <input type="text" name="txtcategory" class="form-control" value="<?php echo $categoryname;?>" required>
                                    

                                </div>

                                <div class="mb-3">

                                    <label>Start Date</label>

                                    <input type="date" name="txtsubmission" class="form-control" value="<?php echo $categorystartdate; ?>" required>

                                </div>

                                <div class="mb-3">

                                    <label>End Date</label>

                                    <input type="date" name="txtfinal" class="form-control" value="<?php echo $categoryclosuredate; ?> "required>

                                </div>

                                <button type="submit" name="btnsubmit" class="btn btn-primary w-100">

                                    <i class="fa fa-save"></i> Update Category

                                </button>

                            </form>

                        </div>

                    </div>


                </div>

            </div>

        </div>

    </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>