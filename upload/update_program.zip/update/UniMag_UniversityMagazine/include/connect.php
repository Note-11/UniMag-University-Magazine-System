<?php  
$host="localhost";
$username="root";
$password="";
$dbname="dbunimag";

// $connection=mysqli_connect($host,$username,$password,$dbname);
$connection=mysqli_connect("localhost","root","","dbunimag");
?>