<?php
session_start();
require_once("include/connect.php");

// 🔒 Only Marketing Manager
if (!isset($_SESSION['roleid']) || $_SESSION['roleid'] != 4) {
    die("Access denied");
}

// 🔒 CHECK FINAL CLOSURE DATE
$check = mysqli_query($connection, "
    SELECT COUNT(*) as open_count 
    FROM tblcategory 
    WHERE categoryclosuredate >= CURDATE()
");

$data = mysqli_fetch_assoc($check);

if ($data['open_count'] > 0) {
    die("Cannot download before final closure date");
}

// ✅ GET ALL SELECTED CONTRIBUTIONS
$query = mysqli_query($connection, "
    SELECT filepath1, filepath2, filepath3
    FROM tblcontribution
    WHERE status = 'selected'
");

$zip = new ZipArchive();
$filename = "ALL_SELECTED_" . time() . ".zip";

if ($zip->open($filename, ZipArchive::CREATE) !== TRUE) {
    die("Cannot create ZIP");
}

$folder = "upload/";

// LOOP ALL CONTRIBUTIONS
while ($row = mysqli_fetch_array($query)) {

    $files = [$row['filepath1'], $row['filepath2'], $row['filepath3']];

    foreach ($files as $file) {
        if ($file && file_exists($folder . $file)) {
            $zip->addFile($folder . $file, $file);
        }
    }
}

$zip->close();

// DOWNLOAD
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename=' . $filename);
readfile($filename);
unlink($filename);
exit();