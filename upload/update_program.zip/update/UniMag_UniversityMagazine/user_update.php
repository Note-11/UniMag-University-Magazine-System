<?php
session_start();
require_once("include/connect.php");

if (!isset($_SESSION['userid'])) {
    echo "<script>
        alert('Please login first');
        window.location='login.php';
    </script>";
    exit();
}

if (!isset($_SESSION['roleid']) || $_SESSION['roleid'] != 1) {
    echo "<script>
        alert('Access denied! Only Admin allowed.');
        window.location='login.php';
    </script>";
    exit();
}

if (isset($_GET['id'])) {

    $userid = $_GET['id'];
    $qry = mysqli_query($connection, "SELECT * FROM tbluser
                                        where userid = '$userid'");
    $row = mysqli_fetch_array($qry);
    $username = $row["username"];
    $email = $row["email"];
    $password_hash = $row["password_hash"];
}
if (isset($_POST['btnsubmit'])) {
    $username = $_POST['txtusername'];
    $email = $_POST['txtemail'];
    $password_hash = $_POST['txtpassword'];

    $check = mysqli_query($connection, "
    SELECT * FROM tbluser 
    WHERE username='$username' 
    AND userid != '$id'
    ");

    if (!empty($_POST['txtpassword'])) {
        $password = password_hash($_POST['txtpassword'], PASSWORD_DEFAULT);

        
    
        $query = mysqli_query($connection, "UPDATE tbluser 
                                set username = '$username', 
                                    email = '$email', 
                                    password_hash = '$password' 
                                    where userid = '$userid'");
    }
    if ($query) {
        echo '<script type = "text/javascript"> 
                alert("Update SUCCESS!"); 
                window.location.href = "register.php"; 
                </script>';
    } else {
        echo "Fail";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <div class="container-fluid">

        <div class="row">

            <!-- SIDEBAR -->

            <div class="col-lg-2 col-md-3 sidebar p-3">

                <h4 class="text-center mb-4">Admin Panel</h4>

                <a href="student_contribution.php"><i class="fa fa-home"></i> Dashboard</a>

                <a href="academic_year_register.php"><i class="fa fa-user-tie"></i> Manage User</a>

                <a href="category_register.php"><i class="fa fa-user-tie"></i> Manage Category</a>

                <a href="register.php"><i class="fa fa-users"></i> Manage Users</a>

                <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>

            </div>


            <!-- MAIN CONTENT -->

            <div class="col-lg-10 col-md-9 p-4">

                <h3 class="mb-4">User Management</h3>

                <div class="row">

                    <!-- ADD ACADEMIC YEAR FORM -->

                    <div class="col-lg-12 col-md-12 mb-4">

                        <div class="card p-3">

                            <h5 class="mb-3">Update User</h5>

                            <form method="POST" action="#">

                                <div class="mb-3">

                                    <label>User</label>

                                    <input type="text" name="txtusername" class="form-control"
                                        value="<?php echo $username; ?>" required>

                                </div>

                                <div class="mb-3">

                                    <label>Email</label>

                                    <input type="email" name="txtemail" class="form-control"
                                        value="<?php echo $email; ?>" required>

                                </div>

                                <div class="mb-3">

                                    <label>Password</label>

                                    <input type="text" class="form-control" name="txtpassword" id="Password"
                                        value="<?php echo $password_hash; ?>" required>

                                </div>

                                <button type="submit" name="btnsubmit" class="btn btn-primary w-100">

                                    <i class="fa fa-save"></i> Update User

                                </button>

                            </form>

                        </div>

                    </div>


                </div>

            </div>

        </div>

    </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>