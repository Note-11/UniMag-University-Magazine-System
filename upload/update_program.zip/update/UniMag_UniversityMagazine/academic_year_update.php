<?php
session_start();
require_once("include/connect.php");

if (!isset($_SESSION['userid'])) {
    echo "<script>
        alert('Please login first');
        window.location='login.php';
    </script>";
    exit();
}

if (!isset($_SESSION['roleid']) || $_SESSION['roleid'] != 1) {
    echo "<script>
        alert('Access denied! Only Admin allowed.');
        window.location='login.php';
    </script>";
    exit();
}

if (isset($_GET['id'])) {

    $acedemicyearid = $_GET['id'];
    $qry = mysqli_query($connection, "SELECT * FROM tblacademicyear
                                        where academicyearid = '$acedemicyearid'");
    $row = mysqli_fetch_array($qry);
    $yearname = $row["yearname"];
    $submission_closure_date = $row["submission_closure_date"];
    $final_closure_date = $row["final_closure_date"];
}
if (isset($_POST['btnupdate'])) {

    $start = $_POST['txtsubmission'];
    $end = $_POST['txtfinal'];

    if ($end < $start) {
        echo "<script>alert('End date cannot be earlier than Start date');
            window.location='academic_year_register.php';
        </script>";
    } else {

        mysqli_query($connection, "
            UPDATE tblacademicyear
            SET yearname='$name',
                submission_closure_date='$start',
                final_closure_date='$end'
            WHERE academicyearid='$id'
        ");

        echo "<script>alert('Updated Successfully');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <div class="container-fluid">

        <div class="row">

            <!-- SIDEBAR -->

            <div class="col-lg-2 col-md-3 sidebar p-3">

                <h4 class="text-center mb-4">Admin Panel</h4>

                <a href="student_contribution.php"><i class="fa fa-home"></i> Dashboard</a>

                <a href="academic_year_register.php"><i class="fa fa-user-tie"></i> Manage Academic Year</a>

                <a href="category_register.php"><i class="fa fa-user-tie"></i> Manage Category</a>

                <a href="register.php"><i class="fa fa-users"></i> Manage Users</a>

                <!-- <a href="student_contribution.php"><i class="fa fa-folder"></i> Student Contribution</a> -->

                <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>

            </div>


            <!-- MAIN CONTENT -->

            <div class="col-lg-10 col-md-9 p-4">

                <h3 class="mb-4">Academic Year Management</h3>

                <div class="row">

                    <!-- ADD ACADEMIC YEAR FORM -->

                    <div class="col-lg-12 col-md-12 mb-4">

                        <div class="card p-3">

                            <h5 class="mb-3">Add Academic Year</h5>

                            <form method="POST" action="#">

                                <div class="mb-3">

                                    <label>Academic Year</label>

                                    <input type="text" name="txtacademicyear" class="form-control" value="<?php echo $yearname;?>" required>

                                </div>

                                <div class="mb-3">

                                    <label>Start Date</label>

                                    <input type="date" name="txtsubmission" class="form-control" value="<?php echo $submission_closure_date; ?>" required>

                                </div>

                                <div class="mb-3">

                                    <label>End Date</label>

                                    <input type="date" name="txtfinal" class="form-control" value="<?php echo $final_closure_date; ?> "required>

                                </div>

                                <button type="submit" name="btnupdate" class="btn btn-primary w-100">

                                    <i class="fa fa-save"></i> Update Academic Year

                                </button>

                            </form>

                        </div>

                    </div>


                </div>

            </div>

        </div>

    </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>